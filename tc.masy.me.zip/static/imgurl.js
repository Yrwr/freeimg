$(document).ready(function(){
	var left_gg = '<a href = "https://www.xiaoz.me/archives/12774" target = "_blank"><img src = "https://i.bmp.ovh/imgs/2019/05/9177285b57dfd962.png" /></a>';
	var right_gg = '<a href = "https://www.xiaoz.me/archives/11183" target = "_blank"><img src = "https://i.bmp.ovh/imgs/2019/05/0fa7eca50fe23133.png" /></a>';
	$("#left-gg").append(left_gg);
	$("#right-gg").append(right_gg);
});